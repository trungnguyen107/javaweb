//package nongsan.webmvc.tools;
//
//public class SendMail {
//
//}
